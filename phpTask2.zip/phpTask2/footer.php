<?php
/**
 * The template for displaying the footer.
 */

?>
<div id="footer">
    <nav>
        <ul id="footer-links">
            <li><a href="#">Privacy</a></li>
            <li><a href="#">Declaimers</a></li>
        </ul>
    </nav>
</div>
</body>
</html>