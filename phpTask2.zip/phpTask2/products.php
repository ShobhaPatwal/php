<?php

include "config.php";
/**
 * Displaying all products
 * 
 * @return void
 */
function showProducts() 
{
    global $products;
    $html = "";
    foreach ($products as $product_key=>$product) {
        $html = "<div id='" .$product['id']. "' class='product'>
		<img src='" .$product['image']. "'>
        <h3 class='title'><a href='#'>" .$product['name']. "</a></h3>
        <span>Price: $" .$product['price']. "</span>
		<a class='add-to-cart' href='#'>Add To Cart</a></div>";
        echo $html;
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
        Products
        </title>
        <link href="style.css" type="text/css" rel="stylesheet">
    </head>
    <?php include "header.php"; ?>
    <div id="main">
        <div id="products">
            <?php
            showProducts();
            ?>
        </div>
    </div>
    <?php include "footer.php"; ?>