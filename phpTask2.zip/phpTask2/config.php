<?php

$siteurl = "http://localhost/training/php/phpTask2/";
$sitename = "PHP Project";
/* Create array for products  */
$products = array( 
    array( 
        "id" => "product-101",
        "image" => "images/football.png",   
        "name" => "Product 101", 
        "price" => "150.00"
     ),
    array(
        "id" => "product-102",
        "image" => "images/tennis.png",
        "name" => "Product 102", 
        "price" => "120.00"
    ),
    array(
        "id" => "product-103",
        "image" => "images/basketball.png",
        "name" => "Product 103", 
        "price" => "90.00"
    ),
    array(
        "id" => "product-104",
        "image" => "images/table-tennis.png",
        "name" => "Product 104", 
        "price" => "110.00"
    ),
    array(
        "id" => "product-105",
        "image" => "images/soccer.png",
        "name" => "Product 105", 
        "price" => "80.00"
    )  
);    
?>